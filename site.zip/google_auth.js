// Google's official token model. Tokens stay in Dart memory, never web storage.
let daybookGoogleLibrary;
function daybookLoadGoogle() {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  if (!daybookGoogleLibrary) daybookGoogleLibrary = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.onload = resolve;
    script.onerror = () => { daybookGoogleLibrary = null; reject(new Error('Google library unavailable')); };
    document.head.appendChild(script);
  });
  return daybookGoogleLibrary;
}
window.daybookGoogleConnect = async (clientId, scopes) => {
  await daybookLoadGoogle();
  return new Promise((resolve, reject) => {
    const client = google.accounts.oauth2.initTokenClient({
      client_id: clientId, scope: scopes, include_granted_scopes: true,
      callback: response => response.error ? reject(new Error(response.error)) : resolve(JSON.stringify(response)),
      error_callback: () => reject(new Error('Google popup closed or blocked')),
    });
    client.requestAccessToken({ prompt: 'select_account' });
  });
};
window.daybookGoogleRevoke = token => new Promise(resolve => {
  if (!window.google?.accounts?.oauth2) return resolve();
  google.accounts.oauth2.revoke(token, resolve);
});
